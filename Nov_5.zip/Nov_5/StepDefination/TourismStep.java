package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TourismPage;
import utils.Base;

public class TourismStep extends Base{
    @When("I get all the links under community")
    public void i_get_all_the_links_under_community() {
        
       }
    @When("click tourism links")
    public void click_tourism_links() {
        TourismPage obj=new TourismPage(driver);
        obj.tourism();
    }
    @When("click contact icon")
    public void click_contact_icon() {
        TourismPage obj=new TourismPage(driver);
        obj.contactUs();
    }
    @Then("I verify the India text")
    public void i_verify_the_india_text() {
        TourismPage obj=new TourismPage(driver);
        obj.IndiaChange();
    }
}
