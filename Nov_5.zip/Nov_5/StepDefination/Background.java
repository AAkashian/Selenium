package stepdefinition;

import java.io.IOException;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import utils.Base;

public class Background extends Base{


@Given("I open url")
   public void i_open_url() throws IOException{
    openBrowser();
    } 

@After
    public void end(){
        driver.quit();
    }

}
