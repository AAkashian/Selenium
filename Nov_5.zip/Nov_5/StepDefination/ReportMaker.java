package stepdefinition;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import utils.Reporter;

public class ReportMaker {
    
    public static ExtentReports reports;
    
    @BeforeAll
    public static void open(){
      reports=Reporter.generateExtentReport("Report Generated");
    }
    @AfterAll
    public static void close(){
       reports.flush();
    }
}
