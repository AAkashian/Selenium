package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.SearchPage;
import utils.Base;

public class SearchStep extends Base{

@When("I get hero header of the page")
public void i_get_hero_header_of_the_page() {
    SearchPage obj=new SearchPage(driver);
    obj.gettingHeroHeader();
}

@When("I click on search icon")
public void i_click_on_search_icon() {
    SearchPage obj=new SearchPage(driver);
    obj.clickSearchIcon();
}

@When("I Search {string} in search icon")
public void i_search_in_search_icon(String string) {
    SearchPage obj=new SearchPage(driver);
    obj.searchString(string);
}

@Then("Validate the ResultPage")
public void validate_the_result_page() {
    SearchPage obj=new SearchPage(driver);
    obj.ValidateString();
 } 

}
