package uistore;

import org.openqa.selenium.By;

public class SearchPageUi {
   public static By searchIcon=By.xpath("//a[@class='nav-link searchBoxIcon']");
   public static By inputBox=By.xpath("//input[@id='searchInputG']");
   public static By heroHeading=By.xpath("(//span[contains(text(),'Tata Digital')])[1]");
   public static By title=By.xpath("//a[@class='cardTitle titleLink']");
}
