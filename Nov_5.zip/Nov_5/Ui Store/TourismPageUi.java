package uistore;

import org.openqa.selenium.By;

public class TourismPageUi {
    public static By tourismLink=By.xpath("(//a[text()='Tourism & Travel'])[2]");
    public static By contact =By.xpath("(//a[@href='/contact-us'])[1]");
    public static By india =By.xpath("//img[@id='icon4']"); 
}
