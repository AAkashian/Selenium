package pages;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import stepdefinition.ReportMaker;
import uistore.SearchPageUi;
import utils.LoggerHandler;
import utils.Screenshot;
import utils.WebDriverHelper;

public class SearchPage {
    WebDriver driver;
    WebDriverHelper helper;
    String header;

    ExtentReports reports;
    ExtentTest test;

    public  SearchPage(WebDriver driver){
       this.driver=driver;
       helper=new WebDriverHelper(driver);
       test = ReportMaker.reports.createTest("test Searchpage created");
    }
 public void gettingHeroHeader(){
   
    helper.waitForElementToBeVisible(SearchPageUi.heroHeading, 10);
     LoggerHandler.info("Sucessfully checked the title");
     test.log(Status.PASS,"test passed");
     header=helper.getText(SearchPageUi.heroHeading);
    System.out.println(header);
    }
 public void clickSearchIcon(){
      helper.clickOnElement(SearchPageUi.searchIcon);
      LoggerHandler.info("Sucessfully clicked On search Icon");
      Screenshot.captureScreenShot("screenshots");
    }
 public void searchString(String searchString){
    helper.waitForElementToBeVisible(SearchPageUi.inputBox, 10);
   helper.sendKeys(SearchPageUi.inputBox, searchString);
   helper.enterAction(SearchPageUi.inputBox);
   Screenshot.captureScreenShot("screenshots");
   }
 public void ValidateString(){
    String actual=helper.getText(SearchPageUi.title);
    //Assert.assertTrue(actual.contains(header));
 }
}
