package pages;

import org.openqa.selenium.WebDriver;

import uistore.TourismPageUi;
import utils.WebDriverHelper;

public class TourismPage {
    WebDriver driver;
    WebDriverHelper helper;
    String header;
    public  TourismPage(WebDriver driver){
       this.driver=driver;
       helper=new WebDriverHelper(driver);
    } 

    public void tourism(){
        helper.clickOnElement(TourismPageUi.tourismLink); 
    }
    public void contactUs(){
        helper.clickOnElement(TourismPageUi.contact);
    }
    public void IndiaChange(){
        helper.clickOnElement(TourismPageUi.india);
    }
}
